#include <iostream>
#include <cstring>
#include <winsock2.h> // Replaces arpa/inet.h and unistd.h on Windows
using namespace std;

int main() {
    WSADATA wsa;
    // Initialize Winsock library on Windows
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cout << "WSAStartup failed" << endl;
        return 1;
    }

    SOCKET clientsocket;
    char buffer[1024] = {0};
    struct sockaddr_in serverAddress;
    int serverlength = sizeof(serverAddress); // int instead of socklen_t for Winsock

    // Create UDP socket (SOCK_DGRAM)
    clientsocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (clientsocket == INVALID_SOCKET) {
        cout << "socket creation failed" << endl;
        WSACleanup();
        return 1;
    }

    // Configure target UDP server address and port 8081
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8081);
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Send datagram message to server
    string msg = "hello server,this is client";
    sendto(clientsocket, msg.c_str(), msg.length(), 0, (struct sockaddr *)&serverAddress, serverlength);
    cout << "msg sent to server" << endl;

    // Receive reply datagram from server
    int bytes = recvfrom(clientsocket, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&serverAddress, &serverlength);
    if (bytes > 0) {
        buffer[bytes] = '\0';
        cout << "reply from server: " << buffer << endl;
    }

    // Close socket and clean up Winsock
    closesocket(clientsocket);
    WSACleanup();
    return 0;
}
