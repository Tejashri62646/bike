#include <iostream>
#include <cstring>
#include <winsock2.h> // Windows socket header instead of arpa/inet.h & unistd.h
using namespace std;

int main() {
    WSADATA wsa;
    // Step 1: Initialize Winsock library (required on Windows)
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cout << "WSAStartup failed" << endl;
        return 1;
    }

    SOCKET serversocket, clientsocket;
    char buffer[1024] = {0};
    struct sockaddr_in serverAddress;

    // Step 2: Create TCP socket
    serversocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serversocket == INVALID_SOCKET) {
        cout << "socket creation failed" << endl;
        WSACleanup();
        return 1;
    }

    // Step 3: Configure server IP and port
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8080);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // Step 4: Bind socket to port 8080
    if (bind(serversocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cout << "bind failed" << endl;
        closesocket(serversocket);
        WSACleanup();
        return 1;
    }

    // Step 5: Listen for incoming connections
    listen(serversocket, 5);
    cout << "server is waiting for client" << endl;

    // Step 6: Accept a client connection
    clientsocket = accept(serversocket, NULL, NULL);
    if (clientsocket == INVALID_SOCKET) {
        cout << "accept failed" << endl;
        closesocket(serversocket);
        WSACleanup();
        return 1;
    }

    cout << "client connected successfully" << endl;

    // Step 7: Receive message from client
    int bytes = recv(clientsocket, buffer, sizeof(buffer) - 1, 0);
    if (bytes > 0) {
        buffer[bytes] = '\0';
        cout << "message received: " << buffer << endl;
    }

    // Step 8: Send reply back to client
    string reply = "hello client, message received";
    send(clientsocket, reply.c_str(), reply.length(), 0);
    cout << "message sent by the server" << endl;

    // Step 9: Close sockets and clean up Winsock
    closesocket(clientsocket);
    closesocket(serversocket);
    WSACleanup();

    return 0;
}
