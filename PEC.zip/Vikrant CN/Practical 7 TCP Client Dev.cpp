#include <iostream>
#include <cstring>
#include <winsock2.h> // Replaces arpa/inet.h and unistd.h on Windows
using namespace std;

int main() {
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { // Initialize Winsock
        cout << "WSAStartup failed" << endl;
        return 1;
    }

    SOCKET clientsocket;
    char buffer[1024] = {0};
    struct sockaddr_in serverAddress;

    clientsocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientsocket == INVALID_SOCKET) {
        cout << "socket creation failed" << endl;
        WSACleanup();
        return 1;
    }

    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8080);
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1"); // Loopback IP for Winsock

    if (connect(clientsocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cout << "connection failed" << endl;
        closesocket(clientsocket);
        WSACleanup();
        return 1;
    }
    cout << "client connected to TCP server" << endl;

    string msg = "hello server, this is tcp client\n";
    send(clientsocket, msg.c_str(), msg.length(), 0);
    cout << "msg sent to server" << endl;

    int bytes = recv(clientsocket, buffer, sizeof(buffer) - 1, 0);
    if (bytes > 0) {
        buffer[bytes] = '\0';
        cout << "server reply: " << buffer << endl;
    }

    closesocket(clientsocket);
    WSACleanup();
    return 0;
}
