#include <iostream>
#include <cstring>
#include <winsock2.h> // Replaces arpa/inet.h and unistd.h on Windows
using namespace std;

int main() {
    WSADATA wsa;
    // Step 1: Initialize Winsock library on Windows
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        cout << "WSAStartup failed" << endl;
        return 1;
    }

    SOCKET serversocket;
    char buffer[1024] = {0};
    struct sockaddr_in serverAddress, clientAddress;
    int clientlength = sizeof(clientAddress); // int instead of socklen_t for Winsock

    // Step 2: Create UDP socket (SOCK_DGRAM)
    serversocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (serversocket == INVALID_SOCKET) {
        cout << "socket creation failed" << endl;
        WSACleanup();
        return 1;
    }

    // Step 3: Configure server address and port 8081
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(8081);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // Step 4: Bind UDP socket to port 8081
    if (bind(serversocket, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) == SOCKET_ERROR) {
        cout << "bind failed" << endl;
        closesocket(serversocket);
        WSACleanup();
        return 1;
    }

    cout << "server is waiting for client" << endl;

    // Step 5: Receive datagram from client and capture clientAddress
    int bytes = recvfrom(serversocket, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&clientAddress, &clientlength);
    if (bytes > 0) {
        buffer[bytes] = '\0';
        cout << "msg received: " << buffer << endl;
    }

    // Step 6: Send reply back to the client's address
    string reply = "hello client, msg received";
    sendto(serversocket, reply.c_str(), reply.length(), 0, (struct sockaddr *)&clientAddress, clientlength);
    cout << "reply sent to client" << endl;

    // Step 7: Close socket and clean up Winsock
    closesocket(serversocket);
    WSACleanup();
    return 0;
}
